import styles from "../../styleCss/register.module.css";
// import Dropdown from "react-dropdown";
import "react-dropdown/style.css";
import useLocationForm from "./useLocationForm";
import Select from "react-select";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import useAxiosPrivate from "../../hooks/useAxiosPrivate";
import Header from "../../components/header/Header";
import NavBar from "../../components/navbar/NavBar";
import Footer from "../../components/footer/Footer";
import { BsFillPersonFill, BsBank2 } from "react-icons/bs";
import { Link } from "react-router-dom";
import FooterCopy from "../../components/footer/FooterCopy";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const eye = <FontAwesomeIcon icon={faEye} />;

const Register = () => {
    const axios = useAxiosPrivate();
    const { state, onCitySelect, onDistrictSelect, onWardSelect } = useLocationForm(true);
    const navigate = useNavigate();
    const [message, setMessage] = useState(null);
    const [passwordShown1, setPasswordShown1] = useState(false);
    const [passwordShown2, setPasswordShown2] = useState(false);

    const togglePasswordVisibility = () => {
        setPasswordShown1(passwordShown1 ? false : true);
    };
    const toggleRePasswordVisibility = () => {
        setPasswordShown2(passwordShown2 ? false : true);
    };

    const { cityOptions, districtOptions, wardOptions, selectedCity, selectedDistrict, selectedWard } = state;

    const [firstName, setFirstName] = useState("");
    const [lastName, setlastName] = useState(null);
    const [gender, setgender] = useState("Male");
    const [dateOfBirth, setdateOfBirth] = useState(null);
    const [email, setEmail] = useState(null);
    const [phone, setPhone] = useState('');
    const [specificAddress, setSpecificAddress] = useState(null);
    const [cardNumber, setcardNumber] = useState('');
    const [dateRangeCard, setdateRangeCard] = useState(null);
    const [cardGrantedPlace, setCardGrantedPlace] = useState(null);
    const [cardFront, setCardFront] = useState(null);
    const [cardBack, setCardBack] = useState(null);
    const [username, setUsername] = useState(null);
    const [password, setPassword] = useState(null);
    const [rePassword, setRePassword] = useState(null);
    const role = "bidder";
    const type = "individual";
    const [isExist, setIsExit] = useState(false);
    const [fileBack, setFileBack] = useState(0);
    const [fileFront, setFileFront] = useState(0);
    const [disable, setDisable] = useState(false);

    //const [usertype] = useState("CONTACT");

    const handleInputChange = (e) => {
        const regexNumber = /^[0-9\b]+$/;
        const { id, value } = e.target;
        if (id === "firstName") {
            setFirstName(value);
        }
        if (id === "lastName") {
            setlastName(value);
        }
        if (id === "gender") {
            setgender(value);
        }
        if (id === "dateOfBirth") {
            setdateOfBirth(value);
        }
        if (id === "email") {
            setEmail(value);
        }
        if (id === "phone") {
            if (value === '' || regexNumber.test(value)) setPhone(value);
        }
        if (id === "specificAddress") {
            setSpecificAddress(value);
        }
        if (id === "cardNumber") {
            if (value === '' || regexNumber.test(value)) setcardNumber(value);
        }
        if (id === "dateRangeCard") {
            setdateRangeCard(value);
        }
        if (id === "cardGrantedPlace") {
            setCardGrantedPlace(value);
        }
        if (id === "cardFront") {
            setCardFront(e.target.files[0]);
        }
        if (id === "cardBack") {
            setCardBack(e.target.files[0]);
        }
        if (id === "userName") {
            setUsername(value);
        }
        if (id === "password") {
            setPassword(value);
        }
        if (id === "rePassword") {
            setRePassword(value);
        }
    };
    const notify = (message) => {
        toast(message, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "light",
        });
    };
    // const [listUsername, setListUsername] = useState([]);
    // const baseURL = `/user/users`;

    const handleSubmit = (event) => {
        const fsizeBack = cardBack.size;
        const fileBack = Math.round(fsizeBack / 1024);
        const fsizeFront = cardFront.size;
        const fileFront = Math.round(fsizeFront / 1024);

        let cityId = selectedCity.value;
        let districtId = selectedDistrict.value;
        let wardId = selectedWard.value;
        const today = new Date();
        const yyyy = today.getFullYear();
        const today2 = new Date(dateOfBirth);
        const yyyy2 = today2.getFullYear();

        const today3 = new Date(dateRangeCard);
        console.log("===================");
        console.log(cardFront.name.lastIndexOf("."));

        var idxDot = cardFront.name.lastIndexOf(".") + 1;
        var extFile = cardFront.name.substring(idxDot, cardFront.length).toLowerCase();
        var idxDot2 = cardBack.name.lastIndexOf(".") + 1;
        var extFile2 = cardBack.name.substring(idxDot2, cardBack.length).toLowerCase();
        console.log(extFile);
        if (!firstName) {
            notify("🦄 FirstName is empty");
        } else if (!lastName.trim()) {
            notify("🦄 LastName is empty");
        } else if (!gender) {
            notify("🦄 Gender is empty");
        } else if (!dateOfBirth) {
            notify("🦄 Date Of Birth is empty");
        } else if (!email.trim()) {
            notify("🦄 Email is empty");
        } else if (!phone.trim()) {
            notify("🦄 phone is empty");
        } else if (!cityId) {
            notify("🦄 city is empty");
        } else if (!districtId) {
            notify("🦄 district is empty");
        } else if (!wardId) {
            notify("🦄 ward is empty");
        } else if (!specificAddress.trim()) {
            notify("🦄 specificAddress is empty");
        } else if (!cardNumber.trim()) {
            notify("🦄 cardNumber is empty");
        } else if (!dateRangeCard.trim()) {
            notify("🦄 dateRangeCard is empty");
        } else if (!cardGrantedPlace.trim()) {
            notify("🦄 cardGrantedPlace is empty");
        } else if (!cardFront) {
            notify("🦄 cardFront is empty");
        } else if (fileBack > 2048) {
            notify("🦄 File card back, please select a file less than 2mb");
        } else if (fileFront > 2048) {
            notify("🦄 File card front, please select a file less than 2mb");
        } else if (!cardBack) {
            notify("🦄 cardBack is empty");
        } else if (!username.trim()) {
            notify("🦄 username is empty");
        } else if (!password.trim()) {
            notify("🦄 password is empty");
        } else if (!rePassword.trim()) {
            notify("🦄 rePassword is empty");
        } else if (isExist) {
            notify("🦄 Username is exist");
        } else if (rePassword != password) {
            notify("🦄 rePassword is not same password");
        } else if (yyyy - yyyy2 < 18) {
            notify("🦄 Date of birth must be more 18 year old");
        } else if (today3 - today > 0) {
            notify("🦄 Date Range Card  must after now");
        } else if (extFile !== "jpg" && extFile !== "jpeg" && extFile !== "png") {
            notify("🦄 Card Front Only jpg/jpeg and png files are allowed");
        } else if (extFile2 !== "jpg" && extFile2 !== "jpeg" && extFile2 !== "png") {
            notify("🦄 Card Back Only jpg/jpeg and png files are allowed");
        } else {
            setDisable(true);

            const formData = new FormData();
            formData.append("firstName", firstName.trim());
            formData.append("lastName", lastName.trim());
            formData.append("gender", gender);
            formData.append("dateOfBirth", dateOfBirth);
            formData.append("email", email.trim());
            formData.append("phone", phone.trim());
            //formData.append("position", position);
            formData.append("cityId", cityId);
            formData.append("city", selectedCity.label);
            formData.append("districtId", districtId);
            formData.append("district", selectedDistrict.label);
            formData.append("wardsId", wardId);
            formData.append("wards", selectedWard.label);
            formData.append("address", specificAddress.trim());
            formData.append("cardNumber", cardNumber.trim());
            formData.append("cardGrantedDate", dateRangeCard.trim());
            formData.append("cardGrantedPlace", cardGrantedPlace.trim());
            formData.append("frontSideImage", cardFront);
            formData.append("backSideImage", cardBack);
            formData.append("username", username.trim());
            formData.append("password", password.trim());
            formData.append("role", role);
            formData.append("type", type);
            axios
                .post(
                    "/individual/create",
                    formData,
                    {
                        headers: { "Content-Type": "multipart/form-data" },
                    },
                    { withCredentials: true }
                )
                .then((res) => {
                    console.log(res);
                    console.log(res.data);
                    setDisable(false);
                    alert("Register successfully!!!");
                    navigate("/login");
                })
                .catch((err) => {
                    //if(err.response.data.status === 409)
                    //console.log(err)
                    setDisable(false);
                    notify(`🦄 Failed: ${err.response.data.message}, ${err}`);
                });
        }

        event.preventDefault();
    };

    return (
        <>
            <Header />
            <NavBar />
            <form onSubmit={handleSubmit}>
                <div className={styles.container}>
                    <ToastContainer
                        position="top-right"
                        autoClose={5000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        theme="light"
                    />
                    {/* Same as */}
                    <ToastContainer />
                    <p className={styles.textCreate}>Create your DAP account</p>
                    <Link to="/login" className={styles.textAd}>
                        Already have an account? Login
                    </Link>
                    <br />
                    <div className={styles.divImg}>
                        <BsFillPersonFill className={styles.icon} />
                        <p className={styles.textFor}>For personal</p>
                    </div>
                    <div className={styles.divImg2}>
                        <Link to="/registerForO">
                            <BsBank2 className={styles.icon} />
                            <p className={styles.textFor}>For organization</p>
                        </Link>
                    </div>
                    <p className={styles.textBlue}>Personal Information</p>
                    <p className={styles.textRed}>Basic information</p>
                    <input
                        className={styles.inputT}
                        type="text"
                        pattern="[a-zA-Z]{1,50}"
                        placeholder="First name"
                        value={firstName}
                        onChange={(e) => handleInputChange(e)}
                        id="firstName"
                        required
                    ></input>
                    <p className={styles.txtBlack}></p>
                    <input
                        className={styles.inputT}
                        type="text"
                        pattern="[a-zA-Z]{1,50}"
                        placeholder="Last name"
                        value={lastName}
                        onChange={(e) => handleInputChange(e)}
                        id="lastName"
                        required
                    ></input>
                    <p className={styles.txtBlack}></p>
                    <select
                        id="gender"
                        className={styles.dropdown}
                        onChange={(e) => handleInputChange(e)}
                        placeholder="Gender"
                        value={gender}
                        defaultValue="Male"
                    >
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                    <p className={styles.txtBlack}>Date of birth</p>
                    <input
                        type="date"
                        className={styles.ipdate}
                        value={dateOfBirth}
                        onChange={(e) => handleInputChange(e)}
                        id="dateOfBirth"
                        required
                    ></input>
                    <input
                        className={styles.inputEP}
                        type="email"
                        pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"
                        placeholder="Email address"
                        value={email}
                        onChange={(e) => handleInputChange(e)}
                        id="email"
                        required
                    ></input>
                    <input
                        className={styles.inputEP}
                        type="text"
                        pattern="[0]\d{9}"
                        placeholder="Phone number"
                        value={phone}
                        onChange={(e) => handleInputChange(e)}
                        id="phone"
                        required
                    ></input>
                    <p className={styles.textRed}>Address</p>
                    <Select
                        className={styles.select}
                        name="cityId"
                        key={`cityId_${selectedCity?.value}`}
                        isDisabled={cityOptions.length === 0}
                        options={cityOptions}
                        onChange={(option) => onCitySelect(option)}
                        placeholder="Tỉnh/Thành"
                        defaultValue={selectedCity}
                    />
                    <Select
                        className={styles.select}
                        name="districtId"
                        key={`districtId_${selectedDistrict?.value}`}
                        isDisabled={districtOptions.length === 0}
                        options={districtOptions}
                        onChange={(option) => onDistrictSelect(option)}
                        placeholder="Quận/Huyện"
                        defaultValue={selectedDistrict}
                    />
                    <Select
                        className={styles.select}
                        name="wardId"
                        key={`wardId_${selectedWard?.value}`}
                        isDisabled={wardOptions.length === 0}
                        options={wardOptions}
                        placeholder="Phường/Xã"
                        onChange={(option) => onWardSelect(option)}
                        defaultValue={selectedWard}
                    />
                    <input
                        className={styles.ipadd}
                        type="text"
                        pattern="^\s*([^\s]\s*){0,300}$"
                        placeholder="Specific address"
                        value={specificAddress}
                        onChange={(e) => handleInputChange(e)}
                        id="specificAddress"
                        required
                    ></input>{" "}
                    <p className={styles.textRed}>Identity/Citizen card</p>
                    <input
                        type="text"
                        pattern="\d{12}"
                        placeholder="Card number"
                        className={styles.ip3}
                        value={cardNumber}
                        onChange={(e) => handleInputChange(e)}
                        id="cardNumber"
                        required
                    ></input>
                    <input type="date" className={styles.ip3} value={dateRangeCard} onChange={(e) => handleInputChange(e)} id="dateRangeCard"></input>
                    <input
                        type="text"
                        pattern="^\s*([^\s]\s*){0,100}$"
                        placeholder="Card granted place"
                        className={styles.ip3}
                        value={cardGrantedPlace}
                        onChange={(e) => handleInputChange(e)}
                        id="cardGrantedPlace"
                        required
                    ></input>
                    <input
                        className={styles.imgCard}
                        id="cardFront"
                        type="file"
                        accept=".png, .jpg, .jpeg"
                        // onChange={(e) => {
                        //   console.log(e.target.files[0]);
                        // }}
                        onChange={(e) => handleInputChange(e)}
                        required
                    />
                    <input
                        id="cardBack"
                        type="file"
                        accept=".png, .jpg, .jpeg"
                        // onChange={(e) => {
                        //   console.log(e.target.files[0]);
                        // }}
                        onChange={(e) => handleInputChange(e)}
                        required
                    />
                    <p className={styles.textBlue}>Account Information</p>
                    <input
                        className={styles.inputEP}
                        type="text"
                        // pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"
                        pattern="?=.{6,20}$"
                        value={username}
                        onChange={(e) => handleInputChange(e)}
                        id="userName"
                        placeholder="Username"
                        required
                    ></input>
                    <div className={styles.fl}>
                        <input
                            className={styles.inputEP}
                            type={passwordShown1 ? "text" : "password"}
                            pattern="^\s*(?:\S\s*){8,}$"
                            value={password}
                            onChange={(e) => handleInputChange(e)}
                            id="password"
                            placeholder="Password"
                            required
                        ></input>
                        <i className={styles.i} onClick={togglePasswordVisibility}>
                            {eye}
                        </i>
                    </div>
                    <div className={styles.fl}>
                        <input
                            className={styles.inputEP}
                            type={passwordShown2 ? "text" : "password"}
                            value={rePassword}
                            onChange={(e) => handleInputChange(e)}
                            id="rePassword"
                            placeholder="Re-eneter the password"
                            required
                        ></input>
                        <i className={styles.i} onClick={toggleRePasswordVisibility}>
                            {eye}
                        </i>
                    </div>
                    <label style={{ color: "red" }}>{message}</label>
                    <input
                        type="submit"
                        className={styles.ipsubmit}
                        value="SIGN UP"
                        style={disable ? { backgroundColor: "red" } : { backgroundColor: "violet" }}
                        disabled={disable}
                    ></input>
                </div>
            </form>

            <Footer />
            <FooterCopy />
        </>
    );
};

export default Register;
