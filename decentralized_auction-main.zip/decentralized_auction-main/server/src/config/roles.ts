export const roles = {
  ADMIN: 'admin',
  MANAGER: 'manager',
  SELLER: 'seller',
  BIDDER: 'bidder'
};
