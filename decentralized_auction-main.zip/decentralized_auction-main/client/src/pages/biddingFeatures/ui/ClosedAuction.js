import React from "react";

const ClosedAuction = ({ auction }) => {
    return <div>ClosedAuction</div>;
};

export default ClosedAuction;
